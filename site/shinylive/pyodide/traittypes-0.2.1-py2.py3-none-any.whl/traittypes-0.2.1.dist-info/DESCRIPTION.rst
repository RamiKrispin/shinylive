Custom trait types for scientific computing.


