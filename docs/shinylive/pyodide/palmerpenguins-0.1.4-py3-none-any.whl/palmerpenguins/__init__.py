from .penguins import load_penguins
from .penguins import load_penguins_raw

__version__ = '0.1.4'
__author__ = 'Muhammad Chenariyan Nakhaee'