c.NotebookApp.open_browser = False
