

def setup_package():
    pass


def teardown_package():
    pass


# True if tests are Reentrant and can be run concurrently
_multiprocess_can_split_ = True
